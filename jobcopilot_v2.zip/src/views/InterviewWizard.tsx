import React, { useState } from "react";
import { Button, Card } from "@/components/ui";
import { ChevronLeft, UploadCloud, FileText, CheckCircle2, Mic, Square, Play, Sparkles, Image as ImageIcon, Type } from "lucide-react";
import * as motion from "motion/react-client";
import { cn } from "@/lib/utils";

type Step = "upload" | "analyze" | "interview" | "review";

interface WizardProps {
  onComplete: () => void;
}

export function InterviewWizard({ onComplete }: WizardProps) {
  const [step, setStep] = useState<Step>("upload");

  return (
    <div className="flex h-full flex-col max-w-4xl mx-auto">
      {/* Header */}
      <header className="flex items-center justify-between pb-8">
        <button
          onClick={() => (step === "upload" ? onComplete() : setStep("upload"))}
          className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow-sm border border-slate-100 transition-colors hover:bg-slate-50"
        >
          <ChevronLeft size={24} className="text-slate-700" />
        </button>
        <span className="font-semibold text-slate-500 tracking-widest text-sm">
          {step === "upload" && "第一步：准备阶段"}
          {step === "analyze" && "第二步：智能分析"}
          {step === "interview" && "第三步：模拟面试"}
          {step === "review" && "第四步：深度复盘"}
        </span>
        <div className="w-12" /> {/* Spacer */}
      </header>

      {/* Content Area */}
      <div className="flex-1">
        {step === "upload" && <UploadStep onNext={() => setStep("analyze")} />}
        {step === "analyze" && <AnalyzeStep onNext={() => setStep("interview")} />}
        {step === "interview" && <InterviewStep onNext={() => setStep("review")} />}
        {step === "review" && <ReviewStep onFinish={onComplete} />}
      </div>
    </div>
  );
}

// --- Steps Components ---

function UploadStep({ onNext }: { onNext: () => void }) {
  const [resumeMode, setResumeMode] = useState<"file" | "text">("file");
  const [jdMode, setJdMode] = useState<"text" | "file">("text");

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-8">
      <div>
        <h2 className="text-4xl font-serif font-bold text-slate-900 mb-2">设定目标岗位</h2>
        <p className="text-slate-500 text-lg">请上传你的求职材料，我们将据此生成精准、贴合岗位的面试问题。</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Resume Card */}
        <Card className="p-6 flex flex-col gap-4 border-2 border-slate-100 hover:border-slate-200 transition-colors">
           <div className="flex justify-between items-start">
             <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600">
               <FileText size={24} />
             </div>
           </div>
           
           <div>
             <h3 className="text-xl font-bold">你的简历</h3>
             <p className="text-sm text-slate-500 mt-1">我们将用它来提取你的过往经历与闪光点。</p>
           </div>
           
           <div className="flex bg-slate-100 p-1 rounded-lg w-fit mt-2">
              <button 
                onClick={() => setResumeMode("file")}
                className={cn("px-4 py-1.5 rounded-md text-sm font-semibold transition-colors flex items-center gap-2", resumeMode === "file" ? "bg-white shadow-sm text-slate-800" : "text-slate-500 hover:text-slate-800")}>
                <UploadCloud size={16}/> 文件/图片
              </button>
              <button 
                onClick={() => setResumeMode("text")}
                className={cn("px-4 py-1.5 rounded-md text-sm font-semibold transition-colors flex items-center gap-2", resumeMode === "text" ? "bg-white shadow-sm text-slate-800" : "text-slate-500 hover:text-slate-800")}>
                <Type size={16}/> 粘贴文本
              </button>
           </div>

           {resumeMode === "file" ? (
             <button className="flex h-40 flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 text-slate-400 hover:bg-slate-100 hover:border-indigo-300 hover:text-indigo-600 transition-all group mt-2 w-full">
               <UploadCloud size={32} className="group-hover:scale-110 transition-transform" />
               <span className="font-semibold text-slate-700">点击或拖拽上传简历</span>
               <span className="text-xs text-slate-500 flex gap-2 items-center mt-1">
                  <FileText size={14}/> PDF / Word
                  <ImageIcon size={14} className="ml-1"/> 图片 (扫描件)
               </span>
             </button>
           ) : (
             <textarea 
               className="w-full flex-1 rounded-2xl bg-white border border-slate-200 p-4 text-sm outline-none placeholder:text-slate-400 min-h-[160px] resize-none focus:ring-2 ring-indigo-500/20 focus:border-indigo-500 transition-all mt-2"
               placeholder="在此处粘贴你的简历纯文本..."
             />
           )}
        </Card>

        {/* JD Card */}
        <Card className="p-6 flex flex-col gap-4 border-2 border-slate-100 hover:border-slate-200 transition-colors">
           <div className="flex justify-between items-start">
             <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600">
               <BriefcaseIcon size={24} />
             </div>
           </div>
           
           <div>
             <h3 className="text-xl font-bold">职位描述 (JD)</h3>
             <p className="text-sm text-slate-500 mt-1">提供目标职位的详细要求，系统将据此对齐考察重点。</p>
           </div>
           
           <div className="flex bg-slate-100 p-1 rounded-lg w-fit mt-2">
              <button 
                onClick={() => setJdMode("file")}
                className={cn("px-4 py-1.5 rounded-md text-sm font-semibold transition-colors flex items-center gap-2", jdMode === "file" ? "bg-white shadow-sm text-slate-800" : "text-slate-500 hover:text-slate-800")}>
                <UploadCloud size={16}/> 文件/截图
              </button>
              <button 
                onClick={() => setJdMode("text")}
                className={cn("px-4 py-1.5 rounded-md text-sm font-semibold transition-colors flex items-center gap-2", jdMode === "text" ? "bg-white shadow-sm text-slate-800" : "text-slate-500 hover:text-slate-800")}>
                <Type size={16}/> 粘贴文本
              </button>
           </div>

           {jdMode === "file" ? (
             <button className="flex h-40 flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 text-slate-400 hover:bg-slate-100 hover:border-emerald-300 hover:text-emerald-600 transition-all group mt-2 w-full">
               <UploadCloud size={32} className="group-hover:scale-110 transition-transform" />
               <span className="font-semibold text-slate-700">上传岗位要求截图或文件</span>
               <span className="text-xs text-slate-500 flex gap-2 items-center mt-1">
                  <ImageIcon size={14}/> 截图/图片
                  <FileText size={14} className="ml-1"/> PDF / Word
               </span>
             </button>
           ) : (
             <textarea 
               className="w-full flex-1 rounded-2xl bg-white border border-slate-200 p-4 text-sm outline-none placeholder:text-slate-400 min-h-[160px] resize-none focus:ring-2 ring-emerald-500/20 focus:border-emerald-500 transition-all mt-2"
               placeholder="在此处粘贴职位描述文本..."
             />
           )}
        </Card>
      </div>

      <Button size="lg" className="w-full md:w-auto md:self-end mt-4 shadow-xl" onClick={onNext}>
        开始智能分析
      </Button>
    </motion.div>
  );
}

function AnalyzeStep({ onNext }: { onNext: () => void }) {
  return (
    <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col gap-8">
       <div>
        <h2 className="text-4xl font-serif font-bold text-slate-900 mb-2">分析完成</h2>
        <p className="text-slate-500 text-lg">以下是你的过往能力与目标岗位的匹配情况。</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
         <Card className="md:col-span-1 p-8 bg-slate-900 text-white flex flex-col items-center justify-center gap-4 border-0">
            <div className="relative flex items-center justify-center h-32 w-32 rounded-full border-8 border-indigo-500/30">
               <span className="text-4xl font-bold">85%</span>
               <svg className="absolute inset-0 h-full w-full -rotate-90">
                 <circle cx="64" cy="64" r="56" fill="none" stroke="currentColor" strokeWidth="8" className="text-indigo-500" strokeDasharray="351" strokeDashoffset="50" />
               </svg>
            </div>
            <span className="font-semibold text-lg">人岗匹配度</span>
         </Card>

         <Card className="md:col-span-2 p-8 flex flex-col gap-6">
            <div>
              <h3 className="flex items-center gap-2 text-lg font-bold text-emerald-600 mb-3"><CheckCircle2 size={20} /> 你的核心优势</h3>
              <ul className="space-y-2">
                <li className="flex gap-2 text-sm text-slate-700 font-medium">✓ 优秀的系统架构设计经验，高度匹配岗位对资深开发者的期待。</li>
                <li className="flex gap-2 text-sm text-slate-700 font-medium">✓ React 和 TypeScript 技能深度契合目标技术栈要求。</li>
              </ul>
            </div>
            <div>
              <h3 className="flex items-center gap-2 text-lg font-bold text-amber-600 mb-3"><Sparkles size={20} /> 预测高频考点</h3>
              <ul className="space-y-2">
                <li className="flex gap-2 text-sm text-slate-700 font-medium">⚠️ 请准备好应对关于“超大型复杂状态管理”的深入探讨。</li>
                <li className="flex gap-2 text-sm text-slate-700 font-medium">⚠️ 面试官极有可能会追问你在 CI/CD 流水线建设上的具体贡献。</li>
              </ul>
            </div>
         </Card>
      </div>

      <Button size="lg" className="w-full md:w-auto md:self-end shadow-xl" onClick={onNext}>
        开始模拟面试
      </Button>
    </motion.div>
  );
}

function InterviewStep({ onNext }: { onNext: () => void }) {
  const [isRecording, setIsRecording] = useState(false);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex h-full flex-col pb-8">
       {/* Live AI Status */}
       <div className="flex flex-col items-center justify-center gap-4 py-12">
          <div className="relative flex h-32 w-32 items-center justify-center rounded-full bg-indigo-50 shadow-inner">
            <div className="absolute inset-0 rounded-full bg-indigo-100 animate-ping opacity-20"></div>
            <Sparkles size={48} className="text-indigo-600" />
          </div>
          <div className="text-center">
            <h2 className="text-2xl font-bold">AI 面试官</h2>
            <p className="text-slate-500">正在倾听...</p>
          </div>
       </div>

       {/* Transcript Area */}
       <Card className="flex-1 p-6 mb-8 bg-white/50 backdrop-blur border border-indigo-100/50 shadow-sm overflow-hidden flex flex-col gap-6">
         <div className="flex gap-4">
           <div className="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center shrink-0"><Sparkles size={16} className="text-indigo-600"/></div>
           <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm text-sm font-medium border border-slate-100">
             "你好，George。我看到你的简历里提到你主导团队把前端架构迁移到了 React。能详细聊讲讲在这个过程中，你遇到过的最大的技术挑战是什么吗？"
           </div>
         </div>
       </Card>

       {/* Controls */}
       <div className="flex items-center justify-center gap-6 mt-auto">
          <Button variant="outline" size="icon" className="h-16 w-16 text-slate-400">
             <Play size={24} fill="currentColor"/>
          </Button>
          
          <button 
            onClick={() => setIsRecording(!isRecording)}
            className={cn(
              "flex h-24 w-24 items-center justify-center rounded-full shadow-2xl transition-all duration-300",
              isRecording ? "bg-red-500 scale-110 ring-8 ring-red-500/20" : "bg-slate-900 hover:bg-slate-800 hover:scale-105"
            )}
          >
             {isRecording ? <Square size={32} className="text-white" fill="currentColor" /> : <Mic size={40} className="text-white" />}
          </button>

          <Button variant="outline" size="icon" className="h-16 w-16 text-slate-900 bg-white shadow-sm" onClick={onNext}>
             <CheckCircle2 size={24}/>
          </Button>
       </div>
    </motion.div>
  );
}

function ReviewStep({ onFinish }: { onFinish: () => void }) {
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-8">
      <div>
        <h2 className="text-4xl font-serif font-bold text-slate-900 mb-2">深度复盘报告</h2>
        <p className="text-slate-500 text-lg">基于实际表现的全方位分析与重塑建议，把每次错误转化为宝贵经验。</p>
      </div>

      <Card className="p-8 pb-0 overflow-hidden bg-slate-900 text-white border-0 flex flex-col md:flex-row gap-8">
         <div className="flex flex-col gap-2 flex-1 pb-8">
           <span className="text-indigo-200 font-semibold tracking-widest text-sm">综合评级</span>
           <div className="flex items-end gap-2">
             <span className="text-7xl font-bold font-serif leading-none">A-</span>
           </div>
           <p className="mt-4 text-slate-300 text-lg">你回答技术问题的逻辑框架很棒。但如果要拿到更高分数，建议在描述中补充“业务影响力”和“衡量指标”。</p>
         </div>
         <div className="md:w-64 bg-indigo-600/20 p-8 flex flex-col justify-center border-l border-white/10 relative">
           <div className="text-sm font-semibold mb-2">核心素质表现</div>
           <div className="space-y-4 w-full">
             <div><div className="flex justify-between text-xs mb-1"><span>沟通与表达</span><span>92%</span></div><div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden"><div className="h-full bg-white w-[92%] rounded-full"></div></div></div>
             <div><div className="flex justify-between text-xs mb-1"><span>技术深度沉淀</span><span>88%</span></div><div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden"><div className="h-full bg-white w-[88%] rounded-full"></div></div></div>
           </div>
         </div>
      </Card>

      <section>
        <h3 className="text-xl font-bold mb-4">案例重塑：把经历升华为满分故事</h3>
        <Card className="p-6 flex flex-col gap-4 border-indigo-100 bg-indigo-50/50">
          <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">你的原始回答</span>
            <p className="text-slate-700 italic text-sm">"我们决定迁移到 React 是因为原来那个老框架太占内存太慢了。我负责搭了新代码库，然后整个团队基本就是一页一页往下重写，大概忙活了好几个月。"</p>
          </div>
          <div className="flex justify-center -my-2 z-10"><div className="bg-indigo-600 text-white rounded-full p-2"><Sparkles size={16}/></div></div>
          <div className="bg-indigo-600 p-5 rounded-xl text-white shadow-md">
            <span className="text-xs font-bold text-indigo-200 uppercase tracking-wider block mb-2">🪄 AI 重塑建议 (套用 STAR 法则)</span>
            <p className="font-medium text-sm leading-relaxed">"当时的旧框架由于渲染性能瓶颈，导致我们移动端页面的转化率流失了30%（情境）。以此为契机，我主导了全面向 React 迁移的技术攻坚战（任务）。为了降低风险，我设计了一套微前端分离架构，让新老页面能共存并逐一替换，实现了零停机升级（行动）。最终在3个月内，我们将首屏加载速度提升了40%，彻底摆脱了技术债，团队迭代速度显著加快（结果）。"</p>
          </div>
        </Card>
      </section>

      <Button size="lg" className="w-full md:w-auto md:self-end mt-4 shadow-xl" onClick={onFinish}>
        返回训练大厅
      </Button>
    </motion.div>
  );
}

// Icon helper
function BriefcaseIcon(props: any) {
  return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><rect width="20" height="14" x="2" y="7" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>;
}
