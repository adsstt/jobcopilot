import React from 'react';
import { Card, Button } from '@/components/ui';
import { Plus, Tag, RefreshCw, Star } from 'lucide-react';
import * as motion from "motion/react-client";

export function StoryLibrary() {
   return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-8">
         <header className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-serif font-bold text-slate-900 mb-2">个人故事库</h1>
              <p className="text-slate-500 text-lg">沉淀你的高光时刻，系统会自动为你翻译成不同考察场景下的满分回答。</p>
            </div>
            <Button className="hidden md:flex gap-2 shadow-sm"><Plus size={18}/> 新增经历</Button>
         </header>

         {/* 移动端新建按钮 */}
         <Button className="md:hidden justify-center gap-2 w-full"><Plus size={18}/> 新增经历</Button>

         <div className="grid gap-6">
            <Card className="p-6 transition-all hover:shadow-md">
               <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4 mb-4">
                 <div>
                   <h3 className="text-xl font-bold">主导移动端前端架构向 React 迁移</h3>
                   <p className="text-sm text-slate-500 mt-1">最近一次修改: 刚才 · 来源于面试复盘收藏</p>
                 </div>
                 <span className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-xs font-bold flex gap-1 items-center self-start">
                    <Star size={12}/> 高分素材
                 </span>
               </div>
               
               <div className="flex flex-wrap gap-2 mb-4">
                 <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-md flex items-center gap-1"><Tag size={12}/> 系统规划</span>
                 <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-md flex items-center gap-1"><Tag size={12}/> 团队协作</span>
                 <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-md flex items-center gap-1"><Tag size={12}/> 技术攻坚</span>
               </div>
               
               <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 text-sm text-slate-700 leading-relaxed relative overflow-hidden">
                 <div className="flex gap-2 overflow-x-auto pb-2 mb-4 border-b border-slate-200 scrollbar-hide">
                    <button className="whitespace-nowrap text-indigo-600 font-bold border-b-2 border-indigo-600 pb-1">STAR 结构版</button>
                    <button className="whitespace-nowrap text-slate-500 font-medium pb-1 px-3 hover:text-slate-800 transition">业务结果版</button>
                    <button className="whitespace-nowrap text-slate-500 font-medium pb-1 px-3 hover:text-slate-800 transition">技术深挖版</button>
                    <button className="whitespace-nowrap text-slate-500 font-medium pb-1 px-3 hover:text-slate-800 transition">管理协作版</button>
                 </div>
                 <div className="space-y-4">
                     <div>
                       <strong className="text-slate-900 block mb-1">Situation (情境)</strong> 
                       之前的旧框架由于渲染性能瓶颈，导致我们移动端页面的极高跳出率，转化率流失了约30%。
                     </div>
                     <div>
                       <strong className="text-slate-900 block mb-1">Task (任务)</strong>
                       作为前端架构负责人，我需要主导全面向 React 迁移的技术攻坚战，且不能影响现有业务迭代。
                     </div>
                     <div>
                       <strong className="text-slate-900 block mb-1">Action (行动)</strong>
                       为了降低风险，我设计了一套微前端分离架构，通过 Nginx 流量分配让新老页面能共存并逐一替换，实现了零停机升级。同时封装了底层的核心组件库供业务开发共用。
                     </div>
                     <div>
                       <strong className="text-slate-900 block mb-1">Result (结果)</strong>
                       最终在3个月内完成核心链路迁移，首屏加载速度（FCP）提升了40%，移动端订单转化率回暖，同时团队日常迭代速度显著加快。
                     </div>
                 </div>
               </div>
               <div className="mt-4 flex flex-col sm:flex-row justify-end gap-3">
                   <Button variant="outline" size="sm" className="gap-2 text-slate-600 w-full sm:w-auto"><RefreshCw size={16}/> 重新生成表达结构</Button>
               </div>
            </Card>

            <Card className="p-6 relative overflow-hidden opacity-60">
              <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/50 backdrop-blur-[2px]">
                 <Button variant="secondary" className="shadow-lg">解锁更多经历槽位</Button>
              </div>
              <div className="flex justify-between items-start mb-4 blur-sm select-none">
                 <div>
                   <h3 className="text-xl font-bold">主导双十一大促营销会场从 0 到 1 建设</h3>
                   <p className="text-sm text-slate-500 mt-1">来源于提取的简历经历</p>
                 </div>
               </div>
               <div className="bg-slate-50 rounded-xl p-4 text-sm text-slate-400 blur-sm select-none h-24">
                 在短时间内协同多个部门完成了...
               </div>
            </Card>
         </div>
      </motion.div>
   )
}
