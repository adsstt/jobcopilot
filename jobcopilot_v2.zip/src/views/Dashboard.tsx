import React from "react";
import { Button, Card } from "@/components/ui";
import { Search, Briefcase, FileText, ArrowUpRight, Code, PenTool, LayoutDashboard } from "lucide-react";
import * as motion from "motion/react-client";
import { cn } from "@/lib/utils";

interface DashboardProps {
  onStartInterview: () => void;
}

export function Dashboard({ onStartInterview }: DashboardProps) {
  const activeRoles = [
    { title: "产品经理", jobs: "3.2k 个岗位", icon: LayoutDashboard, color: "text-indigo-600", bg: "bg-indigo-50" },
    { title: "UX/UI 设计师", jobs: "1.4k 个岗位", icon: PenTool, color: "text-blue-600", bg: "bg-blue-50" },
    { title: "前端开发", jobs: "4.8k 个岗位", icon: Code, color: "text-emerald-600", bg: "bg-emerald-50" },
  ];

  return (
    <div className="flex flex-col gap-10">
      {/* Mobile Header (Hidden on Desktop, shown in Mobile Image 1) */}
      <div className="flex items-center justify-between md:hidden">
        <div className="flex items-center gap-3">
          <img src="https://i.pravatar.cc/100?img=33" alt="George" className="h-12 w-12 rounded-full" />
          <div className="flex flex-col">
            <span className="text-sm text-slate-500">你好</span>
            <span className="text-lg font-bold">George</span>
          </div>
        </div>
        <button className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow-sm border border-slate-100">
          <Briefcase size={20} className="text-slate-700" />
        </button>
      </div>

      <header className="flex flex-col gap-2">
        <span className="text-sm font-semibold tracking-wider text-indigo-600 md:hidden uppercase">训练方向</span>
        <h1 className="font-serif text-5xl font-medium tracking-tight text-slate-900 md:text-6xl italic">
          你好 George 👋<br />
          <span className="not-italic text-4xl md:text-5xl">准备好开始训练了吗？</span>
        </h1>
      </header>

      {/* Main Start Card */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <Card className="flex flex-col gap-6 p-8 relative overflow-hidden bg-slate-900 text-white border-0 shadow-xl">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Briefcase size={120} />
          </div>
          <div className="relative z-10 flex flex-col gap-4 max-w-lg">
            <h2 className="text-3xl font-semibold">开始新的模拟面试</h2>
            <p className="text-indigo-100 text-lg">
              上传你的简历和目标职位描述，获取量身定制的面试痛点分析和预测问题。
            </p>
            <Button size="lg" className="self-start mt-4 bg-white text-slate-900 hover:bg-slate-100 shadow-xl" onClick={onStartInterview}>
              创建练习
            </Button>
          </div>
        </Card>
      </motion.div>

      {/* Role Tracks */}
      <section className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold">你的特定方向</h3>
          <button className="text-sm font-semibold text-slate-500">全部</button>
        </div>
        
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
          {activeRoles.map((role, i) => (
            <motion.div key={role.title} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.3, delay: i * 0.1 }}>
              <Card className="flex cursor-pointer flex-col gap-4 p-5 transition-transform hover:-translate-y-1 hover:shadow-md">
                <div className={cn("flex h-12 w-12 items-center justify-center rounded-2xl", role.bg, role.color)}>
                  <role.icon size={24} />
                </div>
                <div className="flex items-end justify-between">
                  <div className="flex flex-col">
                    <span className="font-bold text-slate-900">{role.title}</span>
                    <span className="text-xs text-slate-500 font-medium">{role.jobs}</span>
                  </div>
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-50 text-slate-400 group-hover:bg-slate-100">
                    <ArrowUpRight size={16} />
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>
      
      {/* Recent History */}
       <section className="flex flex-col gap-4">
        <h3 className="text-xl font-bold">最近练习记录</h3>
        <Card className="p-6">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-4">
               <div className="flex h-14 w-14 items-center justify-center rounded-[20px] bg-red-50 text-red-600">
                  <Briefcase size={24} />
               </div>
               <div className="flex flex-col">
                 <span className="font-bold text-lg">高级交互设计师</span>
                 <span className="text-sm font-medium text-slate-500">Adobe • 2天前</span>
               </div>
            </div>
            <div className="flex flex-col gap-2 md:items-end">
              <span className="text-sm font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full self-start md:self-auto">85% 岗位匹配度</span>
              <span className="text-xs font-semibold text-slate-500">查看报告</span>
            </div>
          </div>
        </Card>
      </section>
    </div>
  );
}
