import React, { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Dashboard } from "@/views/Dashboard";
import { InterviewWizard } from "@/views/InterviewWizard";
import { StoryLibrary } from "@/views/StoryLibrary";
import { Settings } from "@/views/Settings";
import { ResumeLibrary } from "@/views/ResumeLibrary";
import { JobLibrary } from "@/views/JobLibrary";

export type ViewState = "dashboard" | "interview" | "library" | "settings" | "resumes" | "jobs";

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>("dashboard");

  return (
    <Layout currentView={currentView} onViewChange={setCurrentView}>
      {currentView === "dashboard" && <Dashboard onStartInterview={() => setCurrentView("interview")} />}
      {currentView === "interview" && <InterviewWizard onComplete={() => setCurrentView("dashboard")} />}
      {currentView === "library" && <StoryLibrary />}
      {currentView === "resumes" && <ResumeLibrary />}
      {currentView === "jobs" && <JobLibrary />}
      {currentView === "settings" && <Settings />}
    </Layout>
  );
}
