import React from 'react';
import { Card, Button } from '@/components/ui';
import { User, Bell, Shield, Bot } from 'lucide-react';
import * as motion from "motion/react-client";

export function Settings() {
   return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-8">
         <header>
            <h1 className="text-4xl font-serif font-bold text-slate-900 mb-2">系统偏好设置</h1>
            <p className="text-slate-500 text-lg">定制属于你的 AI 面试官风格体系与训练偏好。</p>
         </header>

         <div className="grid md:grid-cols-4 gap-8">
             {/* 侧边设置导航 */}
             <div className="md:col-span-1 flex flex-col gap-2">
                <button className="flex items-center gap-3 p-3 rounded-xl text-slate-500 hover:bg-slate-50 hover:text-slate-900 transition"><User size={18}/> 个人资料</button>
                <button className="flex items-center gap-3 p-3 rounded-xl bg-slate-900 text-white font-semibold shadow-md"><Bot size={18}/> AI 面试偏好</button>
                <button className="flex items-center gap-3 p-3 rounded-xl text-slate-500 hover:bg-slate-50 hover:text-slate-900 transition"><Bell size={18}/> 通知与提醒</button>
                <button className="flex items-center gap-3 p-3 rounded-xl text-slate-500 hover:bg-slate-50 hover:text-slate-900 transition"><Shield size={18}/> 账号与安全</button>
             </div>

             {/* 核心设置内容 */}
             <div className="md:col-span-3 flex flex-col gap-6">
                <Card className="p-6 md:p-8 flex flex-col gap-8 border-0 shadow-sm">
                    <h2 className="text-xl font-bold border-b border-slate-100 pb-4">AI 面试环境配置</h2>
                    
                    <div className="flex flex-col gap-2">
                        <label className="font-bold text-slate-900 flex justify-between items-center cursor-pointer">
                            <span className="text-lg">开启压力面试模式</span>
                            <div className="w-12 h-6 bg-indigo-600 rounded-full flex items-center p-1 justify-end transition-colors shadow-inner">
                                <div className="w-4 h-4 bg-white rounded-full shadow-sm"></div>
                            </div>
                        </label>
                        <p className="text-sm text-slate-500 leading-relaxed pr-12">
                            开启后，AI 将启用严格模式：增加追问频率、发起对逻辑漏洞的反击式质疑，并模拟高并发环境下的高压外企或大厂面试体感。建议在有充分准备后开启。
                        </p>
                    </div>

                    <div className="flex flex-col gap-3 pt-6 border-t border-slate-100">
                        <label className="font-bold text-slate-900 text-lg">AI 面试官话术风格</label>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-2">
                            <div className="border-2 border-indigo-600 bg-indigo-50/50 text-indigo-700 p-4 rounded-xl text-center cursor-pointer transition relative overflow-hidden">
                                <div className="absolute top-0 right-0 bg-indigo-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-bl-lg">当前</div>
                                <div className="font-bold mb-1">外企温和流 (Default)</div>
                                <div className="text-xs text-indigo-600/70 font-medium">鼓励式反馈，礼貌性深挖</div>
                            </div>
                            <div className="border border-slate-200 hover:border-indigo-300 hover:bg-slate-50 p-4 rounded-xl text-center cursor-pointer transition">
                                <div className="font-bold text-slate-700 mb-1">大厂逻辑流</div>
                                <div className="text-xs text-slate-500">直击痛点，重框架轻情绪</div>
                            </div>
                            <div className="border border-slate-200 hover:border-red-300 hover:bg-red-50 p-4 rounded-xl text-center cursor-pointer transition group">
                                <div className="font-bold text-slate-700 group-hover:text-red-700 mb-1">毒舌质疑流</div>
                                <div className="text-xs text-slate-500 group-hover:text-red-600/70">极致施压，挑刺与反驳</div>
                            </div>
                        </div>
                    </div>

                    <div className="flex flex-col gap-3 pt-6 border-t border-slate-100">
                        <label className="font-bold text-slate-900 text-lg">默认面试语言</label>
                        <p className="text-sm text-slate-500 mb-2">设置后，模拟面试中的系统提问与语音识别将以此语言为准。</p>
                        <select className="bg-slate-50 border border-slate-200 rounded-xl p-4 outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 font-medium max-w-sm appearance-none cursor-pointer">
                            <option>中文 (普通话)</option>
                            <option>English (US)</option>
                            <option>中英混合模式 (夹杂职场黑话识别)</option>
                        </select>
                    </div>
                </Card>

                <div className="flex justify-end gap-3 px-2">
                    <Button variant="ghost">取消</Button>
                    <Button className="shadow-lg px-8">保存偏好更改</Button>
                </div>
             </div>
         </div>
      </motion.div>
   )
}
